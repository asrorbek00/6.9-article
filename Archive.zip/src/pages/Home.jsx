function Home() {
    return (
      <div>
          <h1>Home</h1>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci tenetur fuga velit voluptatibus impedit perferendis perspiciatis assumenda, hic delectus non rerum aliquam maxime ea tempora, quidem labore ratione veritatis, quod quasi corporis. Omnis cupiditate natus consectetur amet dolore modi eos necessitatibus molestias. Laborum ducimus alias recusandae! Molestiae earum saepe totam!</p>
      </div>
    )
  }
  
  export default Home