function About() {
    return (
      <div>
          <h1>About</h1>
          <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veritatis facere earum eius aut quod quam, architecto rem doloribus? Ipsa sunt iure vitae possimus eius, facilis rerum omnis explicabo eligendi ratione, obcaecati voluptatum exercitationem? Labore commodi cumque rerum laudantium ut nisi molestias eligendi voluptatibus soluta. Velit iure doloremque cumque repellat, sit libero iste voluptatem quasi inventore odio blanditiis enim. Suscipit accusantium fugit quas beatae ipsam doloribus cupiditate repellendus, ratione nulla ea veritatis vitae. Nisi rerum alias commodi sint ex quas nemo nam sed libero aperiam ab exercitationem id expedita culpa officiis perspiciatis facere tenetur veritatis odio neque, nostrum provident optio dignissimos!</p>
      </div>
    )
  }
  
  export default About