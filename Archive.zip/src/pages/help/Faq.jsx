function Faq() {
    return (
      <div>
          <h2>FAQ</h2>
          <hr />
          <ul>
              <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus corrupti, facilis molestias fugiat, nesciunt optio quas eaque sit saepe ab perferendis recusandae! Numquam natus aliquid, ad molestias rerum ipsam consequuntur. Eius, animi ea. Nam tempore dolor itaque nemo reprehenderit soluta, suscipit, vitae dolores ex autem sed exercitationem voluptatibus? Quibusdam, voluptatibus.</li>
              <li>Ratione reprehenderit deserunt porro autem suscipit quisquam nesciunt! Aut assumenda sed deleniti esse atque nobis excepturi. Ab accusantium possimus tenetur ducimus ut doloribus voluptas, provident excepturi id quia quae in dolore, libero, totam dicta quod. Similique maxime eveniet nam, quaerat minima esse a libero ratione sit animi officiis deserunt enim.</li>
              <li>Quo rem odit impedit odio consequuntur corporis. Minus provident et doloribus quod iusto nemo tempora culpa perferendis, ipsum repudiandae esse ab! Voluptates possimus explicabo nisi placeat maxime consequuntur delectus vero voluptas tempora ratione, eum ipsa suscipit labore, sed vitae architecto at qui officia sunt magni dolorum? Laudantium saepe ipsa magnam.</li>
              <li>Officiis voluptas molestiae tempora placeat eos recusandae adipisci non. Doloribus excepturi, odio iste modi corrupti beatae voluptas. Nemo cumque inventore corrupti molestiae asperiores totam corporis, dignissimos, rem autem unde earum suscipit dolore? Cupiditate eveniet, provident voluptatum dignissimos quo iste culpa deleniti perspiciatis vel voluptatem nobis distinctio rem quod aliquid id.</li>
              <li>Illo, expedita adipisci fuga nihil id, quae distinctio perspiciatis aliquid repellat fugiat maxime iusto ratione asperiores molestias laudantium placeat cum quas recusandae. Quos facilis harum doloremque. Eligendi, delectus! Eum dolorum sint facilis aliquid aut libero quam incidunt aperiam! Ab nam dicta praesentium neque ut temporibus repudiandae corrupti quam id. Quae.</li>
          </ul>
      </div>
    )
  }
  
  export default Faq